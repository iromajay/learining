<?php

namespace frontend\controllers;

use Yii;
use app\models\Questions;
use app\models\Answers;
use app\models\Subjects;
use app\models\QuestionsSearch;
use app\models\Model;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;
use yii\web\Response;
use yii\widgets\ActiveForm;

/**
 * QuestionsController implements the CRUD actions for Questions model.
 */
class QuestionsController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Questions models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new QuestionsSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);  
        $subjectList = ArrayHelper::map(Subjects::find()->all(),'id','name');    
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'subjectList' => $subjectList
        ]);
    }

    /**
     * Displays a single Questions model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Questions model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Questions();
        $subjectList = ArrayHelper::map(Subjects::find()->all(),'id','name');
         $modelsAnswers = [new Answers];

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            $modelsAnswers = Model::createMultiple(Answers::classname());
            Model::loadMultiple($modelsAnswers, Yii::$app->request->post());
            $transaction = \Yii::$app->db->beginTransaction();
            try {
                    if ($flag = $model->save(false)) {
                        foreach ($modelsAnswers as $modelAnswers) {
                            // echo "<pre>";print_r($modelAnswers);die;
                            $modelAnswers->question_id = $model->id;
                            if (! ($flag = $modelAnswers->save(false))) {

                                $transaction->rollBack();

                                break;

                            }

                        }

                    }


                    if ($flag) {

                        $transaction->commit();
                        Yii::$app->session->setFlash("success","Saved successful");
                        return $this->redirect(Yii::$app->request->referrer);


                    }

                } catch (Exception $e) {

                    $transaction->rollBack();

                }

            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->renderAjax('create', [
            'model' => $model,
            'modelsAnswers' => (empty($modelsAnswers)) ? [new Answers] : $modelsAnswers,
            'subjectList' => $subjectList
        ]);
    }

    public function actionAnswers($id) 
    {
        $answers = Answers::find()->asArray()->where(['question_id'=>$id])->all();
        

        return $this->renderAjax('answers',[
            'answers'=>$answers,
        ]);


    }

    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Questions model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Questions model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Questions the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Questions::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
