<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\bootstrap\Modal;
/* @var $this yii\web\View */
/* @var $searchModel app\models\QuestionsSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Questions';
$this->params['breadcrumbs'][] = $this->title;
Modal::begin([
    'id' => 'page-modal-md',
    'clientOptions' => ['backdrop' => 'static', 'keyboard' => false],
    'size' => 'modal-md',
    'header' => '<h3 class="text-center" id="page-modal-lg-header">Answers</h3>'
]);
echo '<div id="page-modal-lg-loader" style="display: none;">
            <div class="loader"></div>
            <div class="fadeMe"></div>
        </div>
        <div id="page-modal-lg-body"><br><br></div>';
Modal::end();
Modal::begin([
    'id' => 'page-modal-lg',
    'clientOptions' => ['backdrop' => 'static', 'keyboard' => false],
    'size' => 'modal-lg',
    'header' => '<h3 class="text-center" id="page-modal-lg-header">Answers</h3>'
]);
echo '<div id="page-modal-lg-loader" style="display: none;">
            <div class="loader"></div>
            <div class="fadeMe"></div>
        </div>
        <div id="page-modal-lg-body"><br><br></div>';
Modal::end();
?>
<div class="questions-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Questions', ['create'], ['class' => 'btn btn-success','onclick' => '$("#page-modal-lg-loader").show();
                            $("#page-modal-lg").modal("show").find("#page-modal-lg-body")
                            .load($(this).attr("href"), function() {

                                ClassicEditor
                            .create( document.querySelector( ".editor" ) )
                            .catch( error => {
                                console.error( error );
                            } );

                                $("#page-modal-lg-loader").hide();
                            });
                            return false;
                        ']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

           
            [
                'attribute'=>'text',
                'format' => 'raw'
            ],
            [
                'attribute' => 'subject_id',
                'value' => function($model)use($subjectList) {
                    return $subjectList[$model->subject_id];

                }
            ],
            //'created_date',
             [
                'attribute' => 'id',
                'filter' => false,
                'value' => function($model) {
                    return  Html::a('Answers', ['answer/index1','id'=>$model->id], ['class' => 'btn btn-primary','onclick' => '
                            $("#page-modal-lg-loader").show();
                            $("#page-modal-md").modal("show").find("#page-modal-lg-body")
                            .load($(this).attr("href"), function() {
                                $("#page-modal-lg-loader").hide();
                            });
                            return false;
                        ', 'style' => 'display: block;']); 
                },
                'format' => 'raw',
            ],
            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>


</div>

<script src="https://cdn.ckeditor.com/ckeditor5/16.0.0/classic/ckeditor.js"></script>

