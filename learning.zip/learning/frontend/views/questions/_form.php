<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

?>

<div class="questions-form">

    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
    	<div class="col-md-4">
    		<?= $form->field($model,"subject_id")->dropDownList($subjectList,["class"=>"form-control","prompt"=>"Select Subject"]) ?>
    	</div>
    	<br>
    	<div class="col-md-2">
		    <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    	</div>
	</div>
	<div class="container">
		<div class="row">
		<div class="col-md-2">
			<label>Question:</label>
		</div>
	</div>
	<div class="row">
		<div class="col-md-8">
		    <textarea name="Questions[text]" id="editor" class="editor">
		    </textarea>
		</div>				
	</div>
	<div class="row">
		<div class="col-md-2">
			<label>Options:</label>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
		    <textarea class="editor"></textarea> 
		</div>
	</div>
	<div class="row">
		<div class="col-md-6">
		    <textarea class="editor"></textarea> 
		</div>
	</div>
	<div class="row">
		<div class="col-md-6">
			  <textarea class="editor"></textarea> 
		</div>
	</div>
	<div class="row"> 
		<div class="col-md-6">
			  <textarea class="editor"></textarea> 
		</div>
	</div>
	<br><br><br><br><br><br>
	<div class="row">
		
	</div>
	
	</div>
	

    <?php ActiveForm::end(); ?>

</div>
<script src="https://cdn.ckeditor.com/ckeditor5/16.0.0/classic/ckeditor.js"></script>
<script type="text/javascript">
	ClassicEditor
            .create( document.querySelector( '.editor' ) )
            .catch( error => {
                console.error( error );
            } );
</script>
