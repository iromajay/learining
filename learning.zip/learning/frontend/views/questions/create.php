<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Questions */

$this->title = 'Create Questions';
$this->params['breadcrumbs'][] = ['label' => 'Questions', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
// Modal::begin([
//     'id' => 'page-modal-lg',
//     'clientOptions' => ['backdrop' => 'static', 'keyboard' => false],
//     'size' => 'modal-md',
//     'header' => '<h3 class="text-center" id="page-modal-lg-header">Answers</h3>'
// ]);
// echo '<div id="page-modal-lg-loader" style="display: none;">
//             <div class="loader"></div>
//             <div class="fadeMe"></div>
//         </div>
//         <div id="page-modal-lg-body"><br><br></div>';
// Modal::end();
?>
<div class="questions-create">

    <!-- <h1><?//= Html::encode($this->title) ?></h1> -->

    <?= $this->render('_form1', [
        'model' => $model,
        'subjectList' => $subjectList,
        'modelsAnswers' => $modelsAnswers
    ]) ?>

</div>
