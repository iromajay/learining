<?php


use yii\helpers\Html;

use yii\bootstrap\ActiveForm;

use wbraganca\dynamicform\DynamicFormWidget;


/* @var $this yii\web\View */

/* @var $modelCustomer app\modules\yii2extensions\models\Customer */

/* @var $modelsOption app\modules\yii2extensions\models\Option */


$js = '

jQuery(".dynamicform_wrapper").on("afterInsert", function(e, item) {

    jQuery(".dynamicform_wrapper .panel-title-Option").each(function(index) {

        jQuery(this).html("Option: " + (index + 1))

    });

});


jQuery(".dynamicform_wrapper").on("afterDelete", function(e) {

    jQuery(".dynamicform_wrapper .panel-title-Option").each(function(index) {

        jQuery(this).html("Option: " + (index + 1))

    });

});

';


$this->registerJs($js);

?>


<div class="questions-form">


    <?php $form = ActiveForm::begin(['id' => 'dynamic-form']); ?>


    <div class="row">
    	<div class="col-md-4">
    		<?= $form->field($model,"subject_id")->dropDownList($subjectList,["class"=>"form-control","prompt"=>"Select Subject"]) ?>
    	</div>
    	<br>
    	<!-- <div class="col-md-2"> -->
		    <!-- <?//= Html::submitButton('Save', ['class' => 'btn btn-success']) ?> -->
    	<!-- </div> -->

    </div>
    <div class="row">
        <div class="col-md-2">
            <label>Question:</label>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <textarea name="Questions[text]" id="editor" class="editor">
            </textarea>
        </div>
    </div>


    <div class="padding-v-md">

        <div class="line line-dashed"></div>

    </div>

    <?php DynamicFormWidget::begin([

        'widgetContainer' => 'dynamicform_wrapper', // required: only alphanumeric characters plus "_" [A-Za-z0-9_]

        'widgetBody' => '.container-items', // required: css class selector

        'widgetItem' => '.item', // required: css class

        'limit' => 4, // the maximum times, an element can be cloned (default 999)

        'min' => 0, // 0 or 1 (default 1)

        'insertButton' => '.add-item', // css class

        'deleteButton' => '.remove-item', // css class

        'model' => $modelsAnswers[0],

        'formId' => 'dynamic-form',

        'formFields' => [

            'test',

        ],

    ]); ?>

    <div class="panel panel-default">

        <div class="panel-heading">

            <i class="fa fa-envelope"></i><label>Options</label> 

            <button type="button" class="pull-right add-item btn btn-success btn-xs"><i class="fa fa-plus"></i> Add Option</button>

            <div class="clearfix"></div>

        </div>

        <div class="panel-body container-items"><!-- widgetContainer -->

            <?php foreach ($modelsAnswers as $index => $modelsAnswers): ?>

                <div class="item panel panel-default"><!-- widgetBody -->

                    <div class="panel-heading">

                        <span class="panel-title-Option">Option: <?= ($index + 1) ?></span>

                        <button type="button" class="pull-right remove-item btn btn-danger btn-xs"><i class="fa fa-minus"></i></button>

                        <div class="clearfix"></div>

                    </div>

                    <div class="panel-body">

                        <?php

                            // necessary for update action.

                            if (!$modelsAnswers->isNewRecord) {

                                echo Html::activeHiddenInput($modelsAnswers, "[{$index}]id");

                            }

                        ?>
                        <div class="row">
                            <div class="col-md-10">
                        <?= $form->field($modelsAnswers, "[{$index}]text")->textInput(['maxlength' => true]) ?>
                            </div>
                            <div class="col-md-2">
                        <?= $form->field($modelsAnswers, "[{$index}]correct")->checkbox(['label' => "Correct"]) ?>
                            </div>

                        </div>
                       


                       

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    </div>

    <?php DynamicFormWidget::end(); ?>


    <div class="form-group">

        <?= Html::submitButton($modelsAnswers->isNewRecord ? 'Create' : 'Update', ['class' => 'btn btn-primary']) ?>

    </div>


    <?php ActiveForm::end(); ?>


</div>
<style type="text/css">
    .ck-editor__editable{
        width: 600px;
    }
    .ck-toolbar{
        width: 600px !important;
    }
</style>
<!-- <script src="https://cdn.ckeditor.com/ckeditor5/16.0.0/classic/ckeditor.js"></script> -->
<!-- <script type="text/javascript">
    // ClassicEditor
    //         .create( document.querySelector( '.editor' ) )
    //         .catch( error => {
    //             console.error( error );
    //         } );
</script> -->