<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\bootstrap\Modal;

 // echo "<pre>Answers";print_r($answers);
?>
<div class="questions-index">

    <h6><?= Html::encode($this->title) ?></h6>

    <!-- <table> -->
        <?php
        $slNo = 1; 
        foreach ($answers as $key => $value) {  ?>
            <div class="container">
                <div >Option <?=$slNo++?> : </div>
                <div ><?= $value["text"] ?></div>
            </div>
        <?php  } ?>
    <!-- </table> -->

    


</div>
<style type="text/css">
    .container{
        display: grid;
        grid-template-columns: 2px 1fr 10fr;
    }
</style>

<?php
$this->registerJs('
    // $("#page-modal-lg-header").val("asd");
');
